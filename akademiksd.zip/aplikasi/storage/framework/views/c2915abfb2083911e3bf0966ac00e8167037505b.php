<html>
    <head>
        <title>KEUANGAN MASUK DAN KELUAR_<?php echo e($tahun); ?>_<?php echo e($bulan); ?></title>
        <style>
            html{
                margin:10px;
            }
            th{
                border:solid 1px #000;
                background:aqua;
                padding-left:10px;
                font-size:12px;
            }
            .tth{
                border:solid 1px #fff;
                padding:1px;
                background:#fff;
                font-size:12px;
            }
            td{
                border:solid 1px #000;
                padding-left:10px;
                font-size:12px;
            }
        </style>
    </head>
    <body>
        <center><h3><u>KEUANGAN MASUK DAN KELUAR PERIODE <?php echo e($tahun); ?><br><?php echo e($kelas); ?></u></h3></center>
        <table width="100%" style="border-collapse:collapse">
            <tr>
                <td class="tth" width="15%"><b>Nilai Keuangan Masuk</b></td>
                <td class="tth" width="30%"><b>:</b> <?php echo e(uang($masuk)); ?></td>
                <td class="tth" width="15%"><b>Periode Bulan</b></td>
                <td class="tth"><b>:</b> <?php echo e($bulan); ?></td>
                
            </tr>
            <tr>
                <td class="tth" ><b>Nilai Keuangan Keluar</b></td>
                <td class="tth"><b>:</b> <?php echo e(uang($keluar)); ?></td>
                <td class="tth"><b>Periode Tahun</b></td>
                <td class="tth"><b>:</b> <?php echo e($tahun); ?></td>
            </tr>
            <tr>
                <td class="tth" ><b>Total</b></td>
                <td class="tth"><b>:</b> <?php echo e(uang($masuk-$keluar)); ?></td>
                <td class="tth"></td>
                <td class="tth"></td>
            </tr>
        </table><hr style="border:dashed 1px #000">
        <table width="100%" style="border-collapse:collapse">
            <tr>
                <th width="5%">No</th>
                <th width=15%">Tanggal</th>
                <th>Nama Transaksi</th>
                <th width=15%">Nilai</th>
                
            </tr>
            <tr>
                <th colspan="4" style="text-align:left">Masuk</th>
            </tr>
                <?php $__currentLoopData = $datamasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$datamasuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no+1); ?></td>
                        <td><?php echo e($datamasuk['tanggal']); ?></td>
                        <td><?php echo e($datamasuk['name']); ?></td>
                        <td><?php echo e(uang($datamasuk['biaya'])); ?></td>
                     </tr>
                    
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th colspan="4" style="text-align:left">Keluar</th>
            </tr>
                <?php $__currentLoopData = $datakeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$datakeluar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no+1); ?></td>
                        <td><?php echo e($datakeluar['tanggal']); ?></td>
                        <td><?php echo e($datakeluar['name']); ?></td>
                        <td><?php echo e(uang($datakeluar['biaya'])); ?></td>
                     </tr>
                    
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </body>
</html>