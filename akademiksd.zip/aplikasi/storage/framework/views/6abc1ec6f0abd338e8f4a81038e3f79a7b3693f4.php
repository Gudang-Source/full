<html>
    <head>
        <title>DAFTAR_ULANG_<?php echo e($tahun); ?>_kelas_<?php echo e($kelas); ?></title>
        <style>
            html{
                margin:10px;
            }
            th{
                border:solid 1px #000;
                background:aqua;
                padding-left:10px;
                font-size:12px;
            }
            td{
                border:solid 1px #000;
                padding-left:10px;
                font-size:12px;
            }
        </style>
    </head>
    <body>
        <center><h3>PEMBAYARAN DAFTAR ULANG PERIODE <?php echo e($tahun); ?><br><?php echo e($kelas); ?></h3></center>
        <table width="100%" style="border-collapse:collapse">
            <tr>
                <th width="5%">No</th>
                <th>Nama</th>
                <th width="10%">Tahun Ajaran</th>
                <th width="6%">Kelas</th>
                <th width="10%">Dibayar</th>
                <th width="10%">Tagihan</th>
                <th width="10%">Potongan</th>
                <th width="10%">Kurang</th>
                
            </tr>
            
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no+1); ?></td>
                        <td>[<?php echo e(cek_siswa($data['siswa_id'])['kode']); ?>] <?php echo e(cek_siswa($data['siswa_id'])['name']); ?></td>
                        <td><?php echo e($data['tahun_ajaran']); ?></td>
                        <td><?php echo e($data['kelas']); ?></td>
                        <td><?php echo e(uang(tagihan_tahun_ajaran_dibayar($data['siswa_id'],$data['tahun_ajaran'],$data['kelas']))); ?></td>
                        <td><?php echo e(uang(tagihan_tahun_ajaran($data['tahun_ajaran'],$data['kelas']))); ?></td>
                        <td><?php echo e(uang(tagihan_tahun_ajaran_potongan($data['siswa_id'],$data['tahun_ajaran'],$data['kelas']))); ?></td>
                        <td><?php echo e(uang((tagihan_tahun_ajaran($data['tahun_ajaran'],$data['kelas'])-tagihan_tahun_ajaran_potongan($data['siswa_id'],$data['tahun_ajaran'],$data['kelas']))-tagihan_tahun_ajaran_dibayar($data['siswa_id'],$data['tahun_ajaran'],$data['kelas']))); ?></td>
                       
                    </tr>
                    
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </table>
    </body>
</html>