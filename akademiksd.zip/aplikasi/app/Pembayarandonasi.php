<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pembayarandonasi extends Model
{
    protected $table = 'pembayaran_donasi';
    public $timestamps = false;
}
