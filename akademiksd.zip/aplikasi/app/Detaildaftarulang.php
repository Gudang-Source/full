<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Detaildaftarulang extends Model
{
    protected $table = 'detail_daftar_ulang';
    public $timestamps = false;
}
