<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pembayaranspp extends Model
{
    protected $table = 'pembayaran_spp';
    public $timestamps = false;
}
