<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kelassiswa extends Model
{
    protected $table = 'kelas_siswa';
    public $timestamps = false;
}
